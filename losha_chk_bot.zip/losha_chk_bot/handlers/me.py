from storage.db import get_connection
from storage.repositories.credits import ensure_row, get_credits
from storage.repositories.bans import is_banned
from security.channel_guard import is_channel_subscribed, send_channel_prompt
from storage.repositories.vip import is_vip_active, get_remaining_time

def register_me(bot):

    @bot.message_handler(commands=["me"])
    def me_handler(message):
        user = message.from_user
        user_id = user.id



        ensure_row(user_id)
        credits = get_credits(user_id)

        name = user.first_name or "NoName"
        username = f"@{user.username}" if user.username else "NoUsername"
        credits_text = "Unlimited" if credits == -1 else credits

        text = f"""
𝐀𝐜𝐜𝐨𝐮𝐧𝐭 𝐈𝐧𝐟𝐨

Name      : {name}
Username  : {username}
User ID   : {user_id}
Credits   : {credits_text}
"""

        # Check VIP status
        if is_vip_active(user_id):
            vip_minutes = get_vip_time_left(user_id)  # time left in minutes

            if vip_minutes < 60:
                vip_time_text = f"{vip_minutes} minutes"
            elif vip_minutes < 1440:  # less than 24 hours
                hours = vip_minutes // 60
                vip_time_text = f"{hours} hours"
            else:
                days = vip_minutes // 1440
                vip_time_text = f"{days} days"

            text += f"\nVIP Status : Active ({vip_time_text} remaining)"

        bot.send_message(message.chat.id, text)