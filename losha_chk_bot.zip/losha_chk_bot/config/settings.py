# ===== ADMINS =====
ADMINS = [6196298047, 7482679982, 6680915317]

# ===== OWNER / BRANDING =====
OWNER_ID = 6196298047
OWNER_NAME = "𝐋𝐎𝐒𝐇𝐀"
CHANNEL_USERNAME = "L_O_S_H_A_1"
HIT_CHAT = -1002465727289
# ===== HTML PARTS =====
CHANNEL_URL = f"https://t.me/{CHANNEL_USERNAME}"
CHANNEL_ICON = f'<a href="{CHANNEL_URL}">ϟ</a>'

# رابط المالك باستخدام tg://user?id=ID
OWNER_URL = f"tg://user?id={OWNER_ID}"
OWNER_HTML = f'<a href="{OWNER_URL}">{OWNER_NAME}</a>'
TOOL_BY = f'{OWNER_HTML} 🥷'